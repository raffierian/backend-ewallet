<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Account;
use App\Models\Family;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    public function index(Request $request)
    {
        $request->validate([
            'family_id' => 'required|exists:families,id',
            'date_from' => 'sometimes|date',
            'date_to' => 'sometimes|date',
            'type' => 'sometimes|in:income,expense,transfer',
            'category_id' => 'sometimes|exists:categories,id',
            'account_id' => 'sometimes|exists:accounts,id',
            'per_page' => 'sometimes|integer|min:1|max:100',
        ]);

        $family = Family::findOrFail($request->family_id);

        // Check if user is member
        if (!$family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        $query = Transaction::where('family_id', $request->family_id)
            ->with(['user', 'account', 'category', 'toAccount']);

        // Apply filters
        if ($request->has('date_from')) {
            $query->where('date', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->where('date', '<=', $request->date_to);
        }

        if ($request->has('type')) {
            $query->where('type', $request->type);
        }

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('account_id')) {
            $query->where('account_id', $request->account_id);
        }

        $transactions = $query->orderBy('date', 'desc')
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 20);

        return response()->json([
            'success' => true,
            'data' => $transactions,
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'family_id' => 'required|exists:families,id',
            'account_id' => 'required|exists:accounts,id',
            'type' => 'required|in:income,expense,transfer',
            'amount' => 'required|numeric|min:0.01',
            'date' => 'sometimes|date',
            'category_id' => 'required_if:type,income,expense|exists:categories,id',
            'note' => 'sometimes|string',
            'receipt' => 'sometimes|image|max:5120', // 5MB max
            'to_account_id' => 'required_if:type,transfer|exists:accounts,id',
        ]);

        $family = Family::findOrFail($request->family_id);
        $account = Account::findOrFail($request->account_id);

        // Check if user is member
        if (!$family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        DB::beginTransaction();
        try {
            $data = [
                'family_id' => $request->family_id,
                'user_id' => $request->user()->id,
                'account_id' => $request->account_id,
                'category_id' => $request->category_id,
                'type' => $request->type,
                'amount' => $request->amount,
                'date' => $request->date ?? now()->toDateString(),
                'note' => $request->note,
                'to_account_id' => $request->to_account_id,
            ];

            // Handle receipt upload
            if ($request->hasFile('receipt')) {
                $path = $request->file('receipt')->store('receipts', 'public');
                $data['receipt_url'] = $path;
            }

            $transaction = Transaction::create($data);

            // Update account balance
            if ($request->type === 'income') {
                $account->increment('balance', $request->amount);
            } elseif ($request->type === 'expense') {
                if ($account->balance < $request->amount) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => 'Insufficient balance',
                    ], 400);
                }
                $account->decrement('balance', $request->amount);
            } elseif ($request->type === 'transfer') {
                $toAccount = Account::findOrFail($request->to_account_id);
                
                if ($account->balance < $request->amount) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => 'Insufficient balance',
                    ], 400);
                }
                
                $account->decrement('balance', $request->amount);
                $toAccount->increment('balance', $request->amount);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Transaction created successfully',
                'data' => $transaction->load(['user', 'account', 'category', 'toAccount']),
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to create transaction: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function show(Request $request, Transaction $transaction)
    {
        // Check if user is member of the family
        if (!$transaction->family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        return response()->json([
            'success' => true,
            'data' => $transaction->load(['user', 'account', 'category', 'toAccount']),
        ]);
    }

    public function update(Request $request, Transaction $transaction)
    {
        // Check if user is member of the family
        if (!$transaction->family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        $request->validate([
            'amount' => 'sometimes|numeric|min:0.01',
            'date' => 'sometimes|date',
            'category_id' => 'sometimes|exists:categories,id',
            'note' => 'sometimes|string',
            'receipt' => 'sometimes|image|max:5120',
        ]);

        DB::beginTransaction();
        try {
            $oldAmount = $transaction->amount;
            $oldType = $transaction->type;

            // Revert old balance changes
            if ($oldType === 'income') {
                $transaction->account->decrement('balance', $oldAmount);
            } elseif ($oldType === 'expense') {
                $transaction->account->increment('balance', $oldAmount);
            } elseif ($oldType === 'transfer') {
                $transaction->account->increment('balance', $oldAmount);
                $transaction->toAccount->decrement('balance', $oldAmount);
            }

            // Update transaction
            $data = $request->only(['amount', 'date', 'category_id', 'note']);
            
            if ($request->hasFile('receipt')) {
                $path = $request->file('receipt')->store('receipts', 'public');
                $data['receipt_url'] = $path;
            }

            $transaction->update($data);

            // Apply new balance changes
            $newAmount = $transaction->amount;
            if ($transaction->type === 'income') {
                $transaction->account->increment('balance', $newAmount);
            } elseif ($transaction->type === 'expense') {
                if ($transaction->account->balance < $newAmount) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => 'Insufficient balance',
                    ], 400);
                }
                $transaction->account->decrement('balance', $newAmount);
            } elseif ($transaction->type === 'transfer') {
                if ($transaction->account->balance < $newAmount) {
                    DB::rollBack();
                    return response()->json([
                        'success' => false,
                        'message' => 'Insufficient balance',
                    ], 400);
                }
                $transaction->account->decrement('balance', $newAmount);
                $transaction->toAccount->increment('balance', $newAmount);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Transaction updated successfully',
                'data' => $transaction->fresh()->load(['user', 'account', 'category', 'toAccount']),
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to update transaction: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function destroy(Request $request, Transaction $transaction)
    {
        // Check if user is member of the family
        if (!$transaction->family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        DB::beginTransaction();
        try {
            // Revert balance changes
            if ($transaction->type === 'income') {
                $transaction->account->decrement('balance', $transaction->amount);
            } elseif ($transaction->type === 'expense') {
                $transaction->account->increment('balance', $transaction->amount);
            } elseif ($transaction->type === 'transfer') {
                $transaction->account->increment('balance', $transaction->amount);
                $transaction->toAccount->decrement('balance', $transaction->amount);
            }

            $transaction->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Transaction deleted successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete transaction: ' . $e->getMessage(),
            ], 500);
        }
    }
}
