<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Family;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function summary(Request $request)
    {
        $request->validate([
            'family_id' => 'required|exists:families,id',
            'period' => 'sometimes|in:today,week,month,year',
        ]);

        $family = Family::findOrFail($request->family_id);

        // Check if user is member
        if (!$family->members->contains($request->user())) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        }

        $period = $request->period ?? 'month';
        $dateFrom = $this->getDateFrom($period);

        // Total balance across all accounts
        $totalBalance = $family->accounts()
            ->where('is_active', true)
            ->sum('balance');

        // Income and expense for the period
        $income = Transaction::where('family_id', $family->id)
            ->where('type', 'income')
            ->where('date', '>=', $dateFrom)
            ->sum('amount');

        $expense = Transaction::where('family_id', $family->id)
            ->where('type', 'expense')
            ->where('date', '>=', $dateFrom)
            ->sum('amount');

        // Top 5 expense categories
        $topExpenseCategories = Transaction::where('family_id', $family->id)
            ->where('type', 'expense')
            ->where('date', '>=', $dateFrom)
            ->select('category_id', DB::raw('SUM(amount) as total'))
            ->with('category')
            ->groupBy('category_id')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        // Recent transactions
        $recentTransactions = Transaction::where('family_id', $family->id)
            ->with(['user', 'account', 'category'])
            ->orderBy('date', 'desc')
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get();

        // Daily trend for the last 7 days
        $dailyTrend = Transaction::where('family_id', $family->id)
            ->where('date', '>=', now()->subDays(7))
            ->select(
                'date',
                'type',
                DB::raw('SUM(amount) as total')
            )
            ->groupBy('date', 'type')
            ->orderBy('date')
            ->get()
            ->groupBy('date')
            ->map(function ($transactions, $date) {
                return [
                    'date' => $date,
                    'income' => $transactions->where('type', 'income')->sum('total'),
                    'expense' => $transactions->where('type', 'expense')->sum('total'),
                ];
            })
            ->values();

        // Budget progress
        $budgets = $family->budgets()
            ->where('is_active', true)
            ->where('period_start', '<=', now())
            ->where('period_end', '>=', now())
            ->with('category')
            ->get()
            ->map(function ($budget) {
                return [
                    'id' => $budget->id,
                    'category' => $budget->category,
                    'amount' => $budget->amount,
                    'spent' => $budget->spent,
                    'progress' => $budget->progress,
                    'remaining' => $budget->amount - $budget->spent,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => [
                'total_balance' => $totalBalance,
                'period_income' => $income,
                'period_expense' => $expense,
                'net_cashflow' => $income - $expense,
                'top_expense_categories' => $topExpenseCategories,
                'recent_transactions' => $recentTransactions,
                'daily_trend' => $dailyTrend,
                'budgets' => $budgets,
            ],
        ]);
    }

    private function getDateFrom($period)
    {
        return match($period) {
            'today' => now()->startOfDay(),
            'week' => now()->startOfWeek(),
            'month' => now()->startOfMonth(),
            'year' => now()->startOfYear(),
            default => now()->startOfMonth(),
        };
    }
}
